﻿namespace System.Windows
{
    public class Media
    {
    }
}